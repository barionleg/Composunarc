# Privacy Noti©e
  [I B M l] Privacy Policy

Our contact details 
Name: IRakli Bardavelidze / Me₽iç Lövoviç
Address: 106 BIS BOULEVARD NEY
, SOLIDARITE JEAN MERLIN Bal 18562, 75018 Paris
Phone Number: 0033758678803
E-mail: alarmhem@live.se
 
The type of personal information we collect 
We currently not collect and process any information.
Your data protection rights
Under data protection law, you have rights including:
Your right of access - You have the right to ask us for copies of your personal information. 
Your right to rectification - You have the right to ask us to rectify personal information you think is inaccurate. You also have the right to ask us to complete information you think is incomplete. 
Your right to erasure - You have the right to ask us to erase your personal information in certain circumstances. 
Your right to restriction of processing - You have the right to ask us to restrict the processing of your personal information in certain circumstances. 
Your right to object to processing - You have the the right to object to the processing of your personal information in certain circumstances.
Your right to data portability - You have the right to ask that we transfer the personal information you gave us to another organisation, or to you, in certain circumstances.
You are not required to pay any charge for exercising your rights. If you make a request, we have one month to respond to you.

How to complain
If you have any concerns about our use of your personal information, you can make a complaint to us at 106 BIS BOULEVARD NEY
, SOLIDARITE JEAN MERLIN Bal 18562, 75018 Paris.
You can also complain to the ICO if you are unhappy with how we have used your data.
The ICO’s address:            
Information Commissioner’s Office
Wycliffe House
Water Lane
Wilmslow
Cheshire
SK9 5AF

Helpline number: 0303 123 1113
ICO website: https://www.ico.org.uk

 



http://stream128.melodiafm.spb.ru:8000/
